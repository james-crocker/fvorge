echo '/dev/sd*' >> /opt/LifeKeeper/subsys/scsi/resources/DEVNAME/device_pattern
