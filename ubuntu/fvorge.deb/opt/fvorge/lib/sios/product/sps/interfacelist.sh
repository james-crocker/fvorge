#!/bin/sh

echo INTERFACELIST=se0 >> /etc/default/LifeKeeper
